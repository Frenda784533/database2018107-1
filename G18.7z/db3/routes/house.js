var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {

    var db = req.con;
    var data = '';

    db.query('SELECT * from householder', function(err, rows) {
        if (err) {
            console.log(err);
        }
        data = rows;
        console.log(data);
        console.log(JSON.stringify(data));
        //res.json(data);
        //res.send(JSON.stringify(data));
        res.render('house', { title: 'Product List', data: data });
    });
});

router.get('/search', function(req, res, next) {
    var db = req.con;
    var id = req.query.id;

    db.query('SELECT * from news where id = ?', id, function(err, rows) {
        if (err) {
            console.log(err);
        }
        data = rows;
        console.log(data);
        console.log(JSON.stringify(data));
        res.render('news', { title: 'Product List', data: data });
    });
});


router.get('/add', function(req, res, next) {
    var db = req.con;
    res.render('houseadd', { title: 'News - Add' });
});


router.post('/add', function(req, res, next) {

    var db = req.con;

    var sql={
        hId:req.body.hId,
        name:req.body.name,
        phone:req.body.phone,
        cId:req.body.cId,
        pId:req.body.pId,
        floor:req.body.floor,
        room:req.body.room,
        zone:req.body.zone
    }

    var qur = db.query('INSERT INTO householder SET ?', sql, function(err, rows) {
        if (err) {
            console.log(err);
        }
        res.setHeader('Content-Type', 'application/json');
        res.redirect('/house');
    });

});



router.get('/delete', function(req, res, next) {
    var db = req.con;
    var id = req.query.id;

    db.query('DELETE from householder where hid=?', id, function(err, rows) {
        if (err) {
            console.log(err);
        }

        res.redirect('/house');
    });

});

module.exports = router;