var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {

    var db = req.con;
    var data = '';

    db.query('SELECT * from waterconsumption', function(err, rows) {
        if (err) {
            console.log(err);
        }
        data = rows;
        console.log(data);
        console.log(JSON.stringify(data));
        //res.json(data);
        //res.send(JSON.stringify(data));
        res.render('water', { title: 'Product List', data: data });
    });
});

router.get('/search', function(req, res, next) {
    var db = req.con;
    var id = req.query.id;

    db.query('SELECT * from news where id = ?', id, function(err, rows) {
        if (err) {
            console.log(err);
        }
        data = rows;
        console.log(data);
        console.log(JSON.stringify(data));
        res.render('news', { title: 'Product List', data: data });
    });
});

router.get('/add', function(req, res, next) {
    var db = req.con;
    res.render('waterAdd', { title: 'News - Add' });
});


router.post('/add', function(req, res, next) {

    var db = req.con;

    var sql={
        hid:req.body.hid,
        record_Start_date:req.body.record_Start_date,
        record_End_date:req.body.record_End_date,
        consumption:req.body.consumption,
        floor:req.body.floor,
        zone:req.body.zone
    }

    var qur = db.query('INSERT INTO waterconsumption SET ?', sql, function(err, rows) {
        if (err) {
            console.log(err);
        }
        res.setHeader('Content-Type', 'application/json');
        res.redirect('/water');
    });

});



router.get('/delete', function(req, res, next) {
    var db = req.con;
    var id = req.query.id;

    db.query('DELETE from waterconsumption where hid=?', id, function(err, rows) {
        if (err) {
            console.log(err);
        }

        res.redirect('/water');
    });

});



module.exports = router;