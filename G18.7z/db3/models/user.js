var mysql = require('mysql');
var DB_NAME = 'db';

var pool  = mysql.createPool({
    host     : 'localhost',
    user     : 'root',
    password : '0000'
});
function User(user){
    this.userid = user.suerid;
    this.password = user.password;
};

User.prototype.save = function save(callback) {
    var user = {
        userid: this.userid,
        password: this.password
    };
};

//檢查是否為會員
User.getUserNumByName = function getUserNumByName(username, callback) {
    //使用username 來檢查是否有資料

     connection.query('select COUNT(1) AS num from user where username = ?', [username], function (err, result) {
         if (err) {
             return;
         }
         connection.release();
         //查詢結果使用 callback 呼叫，並將 err, result 參數帶入
         callback(err,result);                    
     });       
};
//透過帳號取得使用者資料
User.getUserByUserName = function getUserNumByName(userid, callback) {
     connection.query('select * from user where username = ?', [userid], function (err, result) {
         if (err) {
             return;
         }
         connection.release();
         callback(err,result);                    
     });       
 };