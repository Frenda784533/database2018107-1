var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {

    var db = req.con;
    var data = '';

    db.query('SELECT * from activity', function(err, rows) {
        if (err) {
            console.log(err);
        }
        data = rows;
        console.log(data);
        console.log(JSON.stringify(data));
        //res.json(data);
        //res.send(JSON.stringify(data));
        res.render('newact', { title: 'Product List', data: data });
    });
});

router.get('/search', function(req, res, next) {
    var db = req.con;
    var id = req.query.id;

    db.query('SELECT * from news where id = ?', id, function(err, rows) {
        if (err) {
            console.log(err);
        }
        data = rows;
        console.log(data);
        console.log(JSON.stringify(data));
        res.render('news', { title: 'Product List', data: data });
    });
});


router.get('/add', function(req, res, next) {
    var db = req.con;
    res.render('newactAdd', { title: 'News - Add' });
});


router.post('/add', function(req, res, next) {

    var db = req.con;

    var sql={
        activity_no:req.body.activity_no,
        activityTime:req.body.activityTime,
        name:req.body.name,
    }

    var qur = db.query('INSERT INTO activity SET ?', sql, function(err, rows) {
        if (err) {
            console.log(err);
        }
        res.setHeader('Content-Type', 'application/json');
        res.redirect('/newact');
    });

});



router.get('/delete', function(req, res, next) {
    var db = req.con;
    var id = req.query.id;

    db.query('DELETE from activity where activity_no=?', id, function(err, rows) {
        if (err) {
            console.log(err);
        }

        res.redirect('/newact');
    });

});


module.exports = router;