var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {

    var db = req.con;
    var data = '';
    db.query('SELECT * from news', function(err, rows) {
        if (err) {
            console.log(err);
        }
        data = rows;
        console.log(data);
        console.log(JSON.stringify(data));
        //res.json(data);
        //res.send(JSON.stringify(data));
        res.render('news', { title: 'News List', data: data });
    });
});

// router.get('/search', function(req, res, next) {
//     var db = req.con;
//     var id = req.query.id;

//     db.query('SELECT * from news where news_no = ?', id, function(err, rows) {
//         if (err) {
//             console.log(err);
//         }
//         data = rows;
//         console.log(data);
//         console.log(JSON.stringify(data));
//         res.render('news', { title: 'News List', data: data });
//     });
// });


router.post('/add', function(req, res, next) {

    var db = req.con;

    var sql={
        news_no:req.body.news_no,
        notice:req.body.notice,
        date:req.body.date
    }

    var qur = db.query('INSERT INTO news SET ?', sql, function(err, rows) {
        if (err) {
            console.log(err);
        }
        res.setHeader('Content-Type', 'application/json');
        res.redirect('/news');
    });

});

router.get('/add', function(req, res, next) {
    var db = req.con;
    res.render('newAdd', { title: 'News - Add' });
});

router.post('/edit', function(req, res, next) {
    var db = req.con;
    var id = req.body.id;
    var sql={
        news_no:req.body.news_no,
        notice:req.body.notice,
        date:req.body.date
    }

    var qur = db.query('INSERT INTO news SET ?', sql, function(err, rows) {
        if (err) {
            console.log(err);
        }
        res.setHeader('Content-Type', 'application/json');
        res.redirect('/news');
    });


});

router.get('/edit', function(req, res, next) {
    var db = req.con;
    var id = req.query.id;

    db.query('SELECT * from news where news_no = ?', id, function(err, rows) {
        if (err) {
            console.log(err);
        }
        data = rows;
        console.log(data);
        console.log(JSON.stringify(data));
        res.render('newsEdit', { title: 'Product - Edit', data: data });
    });

    

});

router.get('/delete', function(req, res, next) {
    var db = req.con;
    var id = req.query.id;

    db.query('DELETE from news where news_no=?', id, function(err, rows) {
        if (err) {
            console.log(err);
        }

        res.redirect('/news');
    });

});





module.exports = router;